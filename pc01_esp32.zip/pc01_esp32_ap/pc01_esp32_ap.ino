#define BAUDRATE 115200
#define LED 23
#define BUTTON 26

#include <WiFi.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>

// SSID
const char* ssid = "Light_switch_net";
// Password/Empty Password=Open AP   
const char* password = "";           

bool switch_state = false;

void ARDUINO_ISR_ATTR changeState() {
  switch_state = !switch_state;
  Serial.println(switch_state);
  digitalWrite(LED,switch_state);
}

void setup() {
 Serial.begin(BAUDRATE);
 WiFi.mode(WIFI_AP);
 WiFi.softAP(ssid, password);
 delay(1000);  
 Serial.print("\nIP Address: ");   Serial.println(WiFi.softAPIP());    
 pinMode(LED,OUTPUT);
 pinMode(BUTTON,INPUT_PULLUP);
 attachInterrupt(BUTTON,changeState,RISING);
}

void loop() {
 
}


