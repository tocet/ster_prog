#include <ArduinoJson.h> // Library for JSON serialization and deserialization
#include <EEPROM.h>      // Library for flash memory access

// Define the EEPROM size (max 512 bytes for ESP32)
#define EEPROM_SIZE 512

void setup() {
  Serial.begin(115200);
  
  // Initialize EEPROM
  if (!EEPROM.begin(EEPROM_SIZE)) {
    Serial.println("Failed to initialize EEPROM");
    return;
  }

  Serial.println("Reading data from flash memory...");

  String storedJson = "";
  for (int i = 0; i < EEPROM_SIZE; i++) {
    char character = char(EEPROM.read(i));
    if (character == '\0') break; 
    storedJson += character;
  }

  if (storedJson.length() > 0) {
    JsonDocument doc;
    DeserializationError error = deserializeJson(doc, storedJson);

    if (!error) {
      const char* user_id = doc["user_id"];
      const char* password = doc["password"];

      Serial.print("Data retrieved from flash: ");
      Serial.println(storedJson);
      Serial.print("User ID: "); Serial.println(user_id);
      Serial.print("Password: "); Serial.println(password);
    } else {
      Serial.print("JSON Deserialization failed: ");
      Serial.println(error.c_str());
    }
  } else {
    Serial.println("No data found in flash memory.");
  }
}

void loop() {
  JsonDocument doc;
  doc["user_id"] = "admin248";
  doc["password"] = "pass248";

  String jsonString;
  serializeJson(doc, jsonString);

  Serial.print("Saving to flash: ");
  Serial.println(jsonString);

  for (int i = 0; i < jsonString.length(); i++) {
    EEPROM.write(i, jsonString[i]);
  }
  EEPROM.write(jsonString.length(), '\0');

  if (EEPROM.commit()) {
    Serial.println("Data successfully saved to flash!");
  } else {
    Serial.println("Flash save failed!");
  }

  while(1);
}