from machine import Pin,Timer
from utime import sleep

BTN_DELAY = 200
MAIN_DELAY = 500

BTN_ON_PIN = 15
BTN_TOGGLE_PIN = 16

led_state = False
led_toggle = False
led_builtin = Pin(25,Pin.OUT)
btn_on = Pin(BTN_ON_PIN,Pin.IN,Pin.PULL_DOWN)
btn_toggle = Pin(BTN_TOGGLE_PIN,Pin.IN,Pin.PULL_DOWN)

def on_interrupt(Pin):
    global led_state
    led_state = not(led_state)
    btn_on.irq(handler = None)
    timer = Timer(period = BTN_DELAY,mode = Timer.ONE_SHOT,
                  callback = lambda t:
                  btn_on.irq(handler=on_interrupt))
    print("LED on/off int")

def toggle_interrupt(Pin):
    global led_toggle
    led_toggle = not(led_toggle)
    btn_toggle.irq(handler = None)
    timer = Timer(period = BTN_DELAY,mode = Timer.ONE_SHOT,
                  callback = lambda t:
                  btn_toggle.irq(handler=toggle_interrupt))
    print("LED toggle int")

def main_loop(main_timer):
    if led_state:
        if led_toggle:
            led_builtin.toggle()
        else:
            led_builtin.value(1)
    else:
        led_builtin.value(0)

btn_on.irq(trigger=Pin.IRQ_RISING, handler=on_interrupt)
btn_toggle.irq(trigger=Pin.IRQ_RISING, handler=toggle_interrupt)

main_timer = Timer(period = MAIN_DELAY,mode = Timer.PERIODIC,
                   callback = main_loop)

 
