from machine import Pin
from utime import sleep

BTN_ON_PIN = 15
BTN_TOGGLE_PIN = 16

led_state = False
led_toggle = False
led_builtin = Pin(25,Pin.OUT)
btn_on = Pin(BTN_ON_PIN,Pin.IN,Pin.PULL_DOWN)
btn_toggle = Pin(BTN_TOGGLE_PIN,Pin.IN,Pin.PULL_DOWN)

def on_interrupt(Pin):
    global led_state
    led_state = not(led_state)

def toggle_interrupt(Pin):
    global led_toggle
    led_toggle = not(led_toggle)
    
btn_on.irq(trigger=Pin.IRQ_RISING, handler=on_interrupt)
btn_toggle.irq(trigger=Pin.IRQ_RISING, handler=toggle_interrupt)

while True:
    if led_state:
        if led_toggle:
            led_builtin.toggle()
            print("LED toggle mode")
        else:
            led_builtin.value(1)
            print("LED on")
    else:
        led_builtin.value(0)
        print("LED off")
    sleep(0.05)
    
    
