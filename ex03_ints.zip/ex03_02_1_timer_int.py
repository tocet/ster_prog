from machine import Pin,Timer

#on/off time 500ms
DELAY = 500

led_builtin = Pin(25,Pin.OUT)

def led_control(timer):
    led_builtin.toggle()

#timer initialization
timer = Timer(period=DELAY,mode=Timer.PERIODIC,
              callback=led_control) 