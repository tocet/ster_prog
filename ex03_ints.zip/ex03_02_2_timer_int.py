from machine import Pin,Timer

led_builtin = Pin(25,Pin.OUT)

DELAY = 500

# virtual timer
timer = Timer(-1)

#timer initialization
timer.init(period = DELAY,mode = Timer.PERIODIC,
           callback = lambda led:led_builtin.toggle())