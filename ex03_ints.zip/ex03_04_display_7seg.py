# Pico-8SEG-LED
from machine import Pin,SPI
from utime import sleep

RCLK = 9
# SPI pins
SCK = 10
MOSI = 11

# displays
LED_1 = 0xFE  # thousands 0x11111110
LED_2 = 0xFD  # hundreds  0x11111101
LED_3 = 0xFB  # tens      0x11111011
LED_4 = 0xF7  # units     0x11110111
DOT = 0x80

# images
SEG8codes = [0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,
            #   0    1   2    3    4    5    6    7
             0x7F,0x6F,0x77,0x7C,0x39,0x5E,0x79,0x71]  
            #   8    9   A    b    C    d    E    F

class LED_8SEG_DISPLAY():
    def __init__(self):
        self.rclk = Pin(RCLK,Pin.OUT)
        self.rclk(1)
        self.spi = SPI(1)
        self.spi = SPI(1,1000_000)
        self.spi = SPI(1,10000_000,polarity=0,
                       phase=0,sck=Pin(SCK),
                       mosi=Pin(MOSI),miso=None)
        self.SEG8=SEG8codes
    
    def write_cmd(self, Num, Seg):    
        self.rclk(1)
        self.spi.write(bytearray([Num])) # segment select
        self.spi.write(bytearray([Seg])) # segment code
        self.rclk(0)
        sleep(0.002)
        self.rclk(1)

DISPLAY = LED_8SEG_DISPLAY()

while True:
    DISPLAY.write_cmd(LED_1,SEG8codes[1])
    sleep(0.001)
    DISPLAY.write_cmd(LED_2,SEG8codes[3]|DOT)
    sleep(0.001)
    DISPLAY.write_cmd(LED_3,SEG8codes[5])
    sleep(0.001)
    DISPLAY.write_cmd(LED_4,SEG8codes[7]|DOT)
    sleep(0.001)
