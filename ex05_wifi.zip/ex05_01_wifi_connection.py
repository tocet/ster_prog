import time
from network import WLAN, STA_IF
import gc

ssid = "Laboratorium-IoT"
password = ""

gc.collect()

wlan = WLAN(STA_IF)
wlan.active(True)
wlan.connect(ssid,password)

max_wait = 10
while max_wait > 0:
    if wlan.status() < 0 or wlan.status() >= 3:
        break
    max_wait -= 1
    print("Connecting to ",ssid)
    time.sleep(1)

if wlan.status() != 3:
    print(wlan.status())
    raise RuntimeError("Network connection failed")
else:
    print("Connected")
    status = wlan.ifconfig()
    print("IP adres " + status[0])

wlan.disconnect()