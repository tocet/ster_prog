from machine import Pin,PWM
from utime import sleep

#Pins
R_pin = PWM(Pin(2))
G_pin = PWM(Pin(3))
B_pin = PWM(Pin(4))

while True:
    for intensity in range(0, 65000,5000):
        R_pin.duty_u16(intensity)
        sleep(1)