# Import libraries
from imu import MPU6050
from machine import I2C, Pin
import time
import ujson

# Initialize I2C
i2c = I2C(1, sda=Pin(14), scl=Pin(15), freq=400000)  # I2C bus 1, SDA pin 20, SCL pin 21, 400kHz

mpu = MPU6050(i2c)

acceleration = {
    "aX" : mpu.accel.x,
    "aY" : mpu.accel.y,
    "aZ" : mpu.accel.z
}

while True:
# Accelerometer data (x, y, z)
    print("-" * 100)
    json_acc = ujson.dumps(acceleration)
    print(f'x: {acceleration["aX"]} y: {acceleration["aY"]} z: {acceleration["aZ"]}')
    print(json_acc)
    time.sleep(0.5)
# Gyroscope data (x, y, z)
    print("X: %s, Y: %s, Y: %s" % (mpu.gyro.x, mpu.gyro.y, mpu.gyro.z))
    time.sleep(0.5)