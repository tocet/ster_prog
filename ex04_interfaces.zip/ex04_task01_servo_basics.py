from machine import Pin,PWM
from utime import sleep

MIN_POS = 2500
MAX_POS = 9000

servo = PWM(Pin(15))
servo.freq(50)

#angle from 0 to 180
def set_servo_pos(shaft_position):
    servo.duty_u16(shaft_position)
    sleep(0.2)

while True:
    for position in range(MIN_POS,MAX_POS,50):
        set_servo_pos(position)
    for position in range(MAX_POS,MIN_POS,-50):
        set_servo_pos(position)

