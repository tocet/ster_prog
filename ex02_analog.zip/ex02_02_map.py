def analog_map(x, analog_min, analog_max, out_min, out_max):
    return int((x - analog_min) * (out_max - out_min) / (analog_max - analog_min) + out_min)
	
# TEST
y = _map(25, 1, 50, 50, 1)
print(y)