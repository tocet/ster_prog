from machine import ADC
from utime import sleep

#use channel instead number of a pin
temp_sensor = ADC(4)

while True:
    result = temp_sensor.read_u16()
    temperature = 27 - (result*3.3/65535 - 0.706)/0.001721
    print("Temperature: {:.2f}°C".format(temperature))
    sleep(2)