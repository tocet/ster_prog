from machine import ADC
from utime import sleep

def analog_map(x, analog_min, analog_max, out_min, out_max):
    return int((x - analog_min) * (out_max - out_min) / (analog_max - analog_min) + out_min)

joy_X = ADC(26)

while True:
    result = analog_map(joy_X.read_u16(),0,65535,0,10)
    t_string = "X postion = " + str(result)
    print(t_string)
    sleep(1)